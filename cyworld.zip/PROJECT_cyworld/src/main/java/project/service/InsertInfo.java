package project.service;

public interface InsertInfo {

}
